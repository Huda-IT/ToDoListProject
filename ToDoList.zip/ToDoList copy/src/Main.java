import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListManager manager = new ListManager();
		
		//Loop for Creating Tasklist
		boolean addingTask = true;
		
		do{
			manager.addTaskNameAndList();
			System.out.println("More Task? ");
			Scanner read2 = new Scanner(System.in);
			String addMoreTask = read2.nextLine();
		
			if (addMoreTask.equals("y")) 
				addingTask= true;
			else
				addingTask= false;
			}while(addingTask) ;
		
		
		manager.viewAll();
		
		System.out.println(" YOU ARE DONE!");
	}

}
