import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class ListManager {
	
	
	ArrayList< String > taskName= new ArrayList<String>();
	ArrayList <Task> tasks= new ArrayList <Task>();
	
	
	
	
	// Adding task Name as a key and the Tasks in a ArrayList
	public HashMap <String, ArrayList<Task> >  taskMap;
	
	// Constructor of the class 
	public ListManager() {
	taskMap = new HashMap< String, ArrayList <Task>>();
	}
	
	
	public String addTaskName( ) {
		System.out.println(" Name your TO-DO-LIST" );
		Scanner read = new Scanner (System.in);
		String name = read.next();
		return name;
	}
	
	public ArrayList<Task> addList() {
		
		// Scanner for the description 
		Scanner read1 = new Scanner (System.in);
		System.out.println(" Add Description: ");
		String description = read1.nextLine();
		
		//Scanner for Date
		System.out.println(" Add Date in the format: (dd/MM/YYYY)");
		Scanner read = new Scanner (System.in);
		String date1= read.next();	
		SimpleDateFormat format = new SimpleDateFormat ("dd/MM/YYYY");
		
		Date date= null;
		try {
			date = format.parse(date1);
			System.out.println(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println(" Error Formatting !");
			e.printStackTrace();
		}
		
		// Scanner for the status
		boolean status = false;
		Scanner read3 = new Scanner (System.in);
		
		System.out.println(" Select Status: ");
		 status= read3.nextBoolean();
		
		if (status== true)
		System.out.println(" Your Task is done! Good job!");
		else 
			System.out.println(" Task is not done yet!! ");
		
		// adding the scanning values to the ArrayList
		tasks.add(new Task (description, date, status));
		return tasks;
	}
	
	
	public void addTaskNameAndList( ) {
		taskMap.put(addTaskName(), addList());
	}
	
	
	
	public void setAddList(String name, ArrayList<Task> tasks) {
		System.out.println(" This is the set Method");
		for (Map.Entry <String, ArrayList<Task>> entry: taskMap.entrySet()) 
		{
			for (Task s: entry.getValue())
			{
				//addTaskName();
				if(s.equals(addTaskName()))   // check if the task name exist !
				{
					taskName.add(entry.getKey());
					//Loop through the list of Tasks in the ArrayList<tasks>
					for (Iterator <Task> it= entry.getValue().iterator(); it.hasNext();)
					{
						Object list = it.next();
						taskName.add(list.toString());
					}
				}
				System.out.println("This task is already exist!");
			}
			break;
		}
	}
	
	
	// View all the Tasks
	public void viewAll() {
		for (Map.Entry<String, ArrayList<Task>> key :taskMap.entrySet()) {
			System.out.println(key.getKey() +" : ");
			
			ArrayList<Task> tasks= key.getValue( );
					for(Task  task : tasks) {
						System.out.println( task.toString() );
					}
		}
	
	}
	
	
	
	// Sorting the Task objects
	static final Comparator <Task> sortByDate = new Comparator <Task>() {
		public int compare (Task t1, Task t2) {
			return t1.getTaskDate().compareTo(t2.getTaskDate());
		}
	};

}