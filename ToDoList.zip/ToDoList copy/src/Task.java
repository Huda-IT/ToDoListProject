
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


/**
 * 
 */

/**
 * @author tmp-sda-1184
 *
 */
public class Task {

	String description; 
	Date date;
	boolean status;
	
	public Task (String description, Date date, boolean status)  {
		this.description= description;
		this.date= date;
		this.status=status;
	}
	
	
	// Set Description method
	public void setDescription(String description) {
			this.description= description;
	}
	
	// get Description method
	public String getDescription() {
		return description;
	}
	
	
	// Set Task Date method
	public void setTaskDate(Date date) {
		this.date=date;
	}
	
	
	// get the Date of the Task method
		public Date getTaskDate() {
			return date;
		}
	
	
	// set the condition of the Task
	public void setTaskStatus() {
		this.status=status;
	}
	
	
	// get the condition of the Task
	public boolean getTaskStatus() {
		return status;
	}
	
	@Override
	public String toString(){
		return getDescription()+ "   At " + getTaskDate() + "    " + getTaskStatus() + "\n";
		
	}
		
	
}
