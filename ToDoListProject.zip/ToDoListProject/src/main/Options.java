package main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import listManager.*;

public class Options {

	String projectname;
	String description ;
	Date date;
	boolean status;
    int id = 0 ;
    
	public Options() {
		// TODO Auto-generated constructor stub
		
	}
	
	
	
	
	public void printProjectOptions() {
		System.out.println("To Do List Project Options: ");
		System.out.println("------------------------------------------------------------------------------ ");
		System.out.println(" View Tasks for a spacific Project, press 1     ------        Sort All Projects, press 4");
		System.out.println(" Add new Project, press 2   			        ------        Delete a Project, press 5  ");
		System.out.println(" View Projects, press 3                         ------        Exit form the projects, press 6 ");
		//System.out.println('\n');
		
	}
	
	public void printTaskOptions() {
		System.out.println("Task Options: ");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println(" Add new Tasks, press 1      -------------      Edit Tasks, press 3");
		System.out.println(" View Task(s), press 2       -------------      Delete a Task, press 4");
		System.out.println(" Exit this project, press 5");
		//System.out.println('\n');

	}
	
	
	/*public void addTaskValues() {
			TaskManager manager = new TaskManager();
			Scanner read = new Scanner (System.in);
			
			
			boolean tProcess = true;			
			while( tProcess ) {
			printTaskOptions();
			int taskChoice =read.nextInt();
			if ( taskChoice == 1 ) {
				
				System.out.println(" Add New Tasks: ");
				
				// Scanning Task Description
				System.out.println(" Add Description: ");
				description = read.next();
				
				// Scanning Task Date
				System.out.println(" Add Date in this format: (dd-MM-yyyy)");
				String date1= read.next();	
				SimpleDateFormat dateFormat = new SimpleDateFormat ("dd-MM-yyyy" );
						
				date= null;
				try {
					date = dateFormat.parse(date1);
					System.out.println(dateFormat.format(date));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					System.out.println(" Error Formatting !");
					e.printStackTrace();
				}
				
				
				// Scanning Task Status
				status = false;
				System.out.println("Select Status: ");
				status= read.nextBoolean();
				
				if (status== true)
					System.out.println(" Your Task is done! Good job!");
				else 
					System.out.println(" Task is not done yet!! ");
			
				
				Task task = new Task(projectname,  description, date,  status, id);
				//projectname = task.getProject();
				manager.addProjectTasks (projectname,  description, date, status, id); 
			}

			
			if ( taskChoice == 2 ) {
				System.out.println(" The Task(s) are: " + '\n');
				manager.viewAllTasks();
				//readfile.ReadProject();
			}
			
			
			if ( taskChoice == 3 ) {
				System.out.println(" Enter Task number you want to Edit: "); 
				id = read.nextInt();
				manager.editTaskById (id,projectname, description, date, status);
			}
			
			if ( taskChoice == 4) {
				System.out.println(" Select the Task you want to delete: ");
				int index = read.nextInt();
				manager.getTaskById(index);
				manager.deleteTaskById (index);
			}
			
			if ( taskChoice == 5 ) {
				System.out.println(" You are Done with your Tasks and Existing! ");
				tProcess = false;
			}
			
		}  */
			
		
	}
	
