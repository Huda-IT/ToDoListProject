package main;
import listManager.TaskManager;
import listManager.Writefile;
import listManager.Task;
import listManager.Readfile;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Main {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String projectname;
		String description ;
		Date date;
		boolean status;
	    int id = 0 ;
		//ArrayList<Task> tasks = new ArrayList<>();
		//HashMap<String, ArrayList<Task> > taskMap ;
		
		// Load Project Names
		TaskManager manager = new TaskManager();
		
		//System.out.println();
		Scanner read = new Scanner (System.in);
		Options option = new Options();
		Readfile readfile = new Readfile();
		
		// Printing Project Options on Screen
		//option.printProjectOptions();
		
		boolean process = true;	
		while( process ) {
		option.printProjectOptions();
		int choice =read.nextInt();
			
		if ( choice == 1 ) {
			System.out.println ( " Enter Project Name to view its Tasks:");
			projectname = read.next();
			manager.viewTasksForProject(projectname);	
		}
		
		else if ( choice == 2 ) {
			System.out.println(" Enter Project Name: ");
			projectname = read.next();
			System.out.println('\n');
			// Adding Task information
			//option.addTaskValues();
			

			boolean tProcess = true;			
			while( tProcess ) {
			option.printTaskOptions();
			int taskChoice =read.nextInt();
			
				if ( taskChoice == 1 ) {
				
				System.out.println(" Add New Tasks: ");
				
				// Scanning Task Description
				System.out.println(" Add Description: ");
				description = read.next();
				
				// Scanning Task Date
				System.out.println(" Add Date in this format: (dd-MM-yyyy)");
				String date1= read.next();	
				SimpleDateFormat dateFormat = new SimpleDateFormat ("dd-MM-yyyy" );
						
				date= null;
				try {
					date = dateFormat.parse(date1);
					System.out.println(dateFormat.format(date));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					System.out.println(" Error Formatting !");
					e.printStackTrace();
				}
				
				
				// Scanning Task Status
				status = false;
				System.out.println("Select Status: ");
				status= read.nextBoolean();
				
				if (status== true)
					System.out.println(" Your Task is done! Good job!");
				else 
					System.out.println(" Task is not done yet!! ");
			
				
				Task task = new Task(projectname,  description, date,  status, id);
				//projectname = task.getProject();
				manager.addProjectTasks (projectname,  description, date, status, id); 
			}
			
			if ( taskChoice == 2 ) {
				System.out.println(" The Task(s) are: " + '\n');
				manager.viewAllTasks();
				//readfile.ReadProject();
			}
			
			if ( taskChoice == 3 ) {
				System.out.println(" Enter Task number you want to Edit: "); 
				id = read.nextInt();
				manager.editTaskById (id);
			}
			
			if ( taskChoice == 4) {
				System.out.println(" Select the Task you want to delete: ");
				int index = read.nextInt();
				manager.getTaskById(index);
				manager.deleteTaskById (index);
			}
			
			if ( taskChoice == 5 ) {
				System.out.println(" You are Done with your Tasks and Existing! ");
				tProcess = false;
			}
			
		}  
				
		}
		
		else if ( choice == 3 ) {
			System.out.println(" The Projects are: ");
			readfile.ReadProject();
		}
		
		
		else if ( choice == 4 ) {
			System.out.println(" Sorting Projects by Date: ");
			

		}
		
		else if ( choice == 5 ) {
			System.out.println(" Enter Project Name you want delete: ");
			String projectDelete = read.next();
			manager.deleteProject(projectDelete);

		}

		else if ( choice == 6 ) {
			System.out.println(" Done with this project, save and quite! ");
			Writefile writeFile = new Writefile();
			//writeFile.writeToFile(tasks);
			process = false;
		}
		
		else
			System.out.println(" This is invald option number!! " + '\n');
}
	}
}