package listManager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


public class Writefile {

	String filename = "SavedTasks/projectstor.txt";
	String tempfile = "SavedTasks/tempfile.txt";
	
	public Writefile() {
		// TODO Auto-generated constructor stub
		
	}

	
	public boolean writeToFile( HashMap<String, ArrayList<Task>> taskMap) {
		boolean success = false;
		try {
			FileWriter writer = new FileWriter (filename, true); 
			BufferedWriter bwriter = new BufferedWriter(writer);
			
			for (Entry<String, ArrayList<Task>> key :taskMap.entrySet()) {
				System.out.println(key.getKey() + " : " + '\n');
				List<Task> tasks= key.getValue( );
				//bwriter.write(key.getKey() +  '\n') ;
					for(Task task : tasks) {
						bwriter.write(task.getId()+ ":" + task.getProject() + ":" + task.getDescription() + ":" 
		+ task.getTaskDate().toString() + ":" + task.getTaskStatus());
						bwriter.newLine();
					}
			}
			
		bwriter.close();
		
		}catch (IOException e) {
			System.err.println(" There was a problem writing to "+ filename);
		}
			return success;
		}	
	
	
 /*	public void removeTaskByIdfromFile(int id) {
			try {
				PrintWriter writer = new PrintWriter (tempfile); 
				BufferedReader reader = new BufferedReader(new FileReader(filename));
			
				String IDtoDelete =String.valueOf(id);
				String line;
				while ((line = reader.readLine()) != null) {
				
					String[ ] parts = line.split(":");
					String IDinFile = String.valueOf(parts [0]);
					//if ( IDtoDelete.equalsIgnoreCase(IDinFile))
					if ( !id.equals())
						writer.print(line);
						writer.flush();
					}
				}
				writer.close();
				br1.close();
			}
			catch ( FileNotFoundException e) {
					System.err.println("Unable to open the file "+ this.filename);
				} catch (IOException e) {
					System.err.println("A problem in reading "+ this.filename);
				}
			
	} */
	
	
	
	}

	

