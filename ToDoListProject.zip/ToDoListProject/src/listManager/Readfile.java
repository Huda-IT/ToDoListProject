package listManager;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;



public class Readfile {
	
	String filename = "SavedTasks/projectstor.txt"; 
	
	
	public Readfile() {
		// TODO Auto-generated constructor stub
		
	}
	
		public void ReadProject() {
		try { 
		
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String line;
			while ((line = reader.readLine()) != null) {
				String[ ] parts = line.split(":");
				System.out.println(parts[0] + " " + parts[1] + " " + parts[2] + " " +  parts[3] + " " 
				+ parts[4] );
			}
			
			reader.close();
		} catch ( FileNotFoundException e) {
			System.err.println("Unable to open the file "+ this.filename);
		} catch (IOException e) {
			System.err.println("A problem in reading "+ this.filename);
		}
		
	}
		
	
		public void ReadProjectNames() {
			try { 
				
				BufferedReader reader = new BufferedReader(new FileReader(filename));
				String line;
				System.out.println(" Saved Projects are:  ");
				while ((line = reader.readLine()) != null) {
					String[ ] parts = line.split(":");
					System.out.println(parts[1]  + " ");
			}
				reader.close();
			} catch ( FileNotFoundException e) {
				System.err.println("Unable to open the file "+ this.filename);
			} catch (IOException e) {
				System.err.println("A problem in reading "+ this.filename);
			}
		}

}
