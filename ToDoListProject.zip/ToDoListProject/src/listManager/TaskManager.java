package listManager;
import main.Options;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;



public class TaskManager {
	
	HashMap<String, ArrayList<Task> > taskMap ; 
	ArrayList<Task> tasks = new  ArrayList<Task>();
	private int currentId;
	
	//Task task = new Task (projectname,  description,  date, status) ;
	
	
	public TaskManager() {
		// TODO Auto-generated constructor stub
		taskMap = new HashMap<String, ArrayList<Task>>();
		currentId = 1;
	}
	
	
	//public String projectName( String projectname) {
	//	String project = task.getProject();
	//	return project;
	//}
	
	
	
	public void addProjectTasks (String projectname,  String description, Date date, boolean status, int currentId) {
		
		//task= new Task (project,  description,  date, status) ;
		ArrayList<Task> tasks = taskMap.get(projectname);
		if (tasks == null) {
			tasks = new ArrayList<Task>();
			tasks.add(new Task(projectname,  description, date, status, currentId));
			currentId++;
			taskMap.put(projectname, tasks);
		} else {
			Task newTask = new Task(projectname,  description, date, status, currentId);
			if (!tasks.contains(newTask)) {
				tasks.add(newTask);
				currentId++;
				taskMap.put(projectname, tasks);
			}
		}
	}
	
	
	public void KeySetArray() {
		//Set<String> keySet = taskMap.keySet();
		//ArrayList <String> listofkeys = new ArrayList <>(keySet);
		for (Map.Entry<String, ArrayList<Task>> key :taskMap.entrySet()) 
			System.out.println(key.getKey() + " : ");
	}
	
	//public void AddToHashMap(String projectname, ArrayList<Task> tasks ){
	//	taskMap.put(projectname,tasks);
	//}

	
	// View all Projects 
	public void ViewAllProjects() {
		if (tasks == null)
			System.out.println();
		else {
		for (String key: taskMap.keySet())
		System.out.println(key + '\n');
		}
	}
	
	// View all the Tasks in selected project
		public void viewAllTasks() {
			
			for (Map.Entry<String, ArrayList<Task>> key :taskMap.entrySet()) {
				System.out.println(key.getKey() + " : " + '\n');
				ArrayList<Task> tasks= key.getValue( );
					for(int i = 0; i < tasks.size(); i++) {
						System.out.println( tasks.get(i));
					}
			}
		}
		
		// Check Task Id if is exist !
		public Task getTaskById (int wantedId) {
			
			for (Map.Entry<String, ArrayList<Task>> entry : taskMap.entrySet() ) {
				System.out.println( entry.getKey()+ " : ");
				ArrayList<Task> tasks = entry.getValue();
				for (int i=0; i< tasks.size() ; i++) {
					Task t = tasks.get(i);
					if (t.getId() == wantedId) {
						return t;
					}
				}
			}
			return null;
		}
		
		/* Deleting Task by selected id using getTaskById (int wantedId) method
		 * 
		 */
		public void deleteTaskById (int id) {
			Task t = getTaskById (id);
			// check if the wanted id exist, if not the method will return null!
			if (t == null) {
				return;
			}
			Task project = t;	
			tasks.remove(project);
			System.out.println(" The Task has been removed!");
		}
		
		
		//public void editTaskById (int id, String newProjectname, String newDescription, Date newDate, boolean newStatus) {
		public void editTaskById (int id) {	
		Task t = getTaskById(id);
			
			if ( t == null) {
				return;
			}
			
			deleteTaskById (id);
			
			// Adding new Task ( Editing the task )
			//Options option = new Options();
			 //option.addTaskValues();
			Scanner read = new Scanner (System.in);
			System.out.println(" Add New Tasks: ");
			
			
			String oldProjectname = t.getProject();
			System.out.println(" Add new Project Name: ");
			String newProjectname = read.next();
		
			if (newProjectname == null)
				newProjectname = oldProjectname;
			
			String oldDescription = t.getDescription();
			System.out.println(" Add new Description: ");
			String newDescription = read.next();
			if (newDescription == null)
				newDescription = oldDescription;
			
			Date oldDate = t.getTaskDate();
			System.out.println(" Add new Date in this format: (dd-MM-yyyy): ");
			String newDate2 = read.next();
			SimpleDateFormat dateFormat = new SimpleDateFormat ("dd-MM-yyyy" );
			
			Date newDate = null;
			try {
			    newDate = dateFormat.parse(newDate2);
				System.out.println(dateFormat.format(newDate));
				if (newDate == null)
					newDate = oldDate;
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				System.out.println(" Error Formatting !");
				e.printStackTrace();
			}
			
			
			boolean oldStatus = t.getTaskStatus();
			System.out.println(" Update Status: ");
			boolean newStatus = read.nextBoolean();
			if (newStatus = null != null)
				newStatus = oldStatus ;
			
			addProjectTasks(newProjectname,  newDescription, newDate, newStatus, currentId);
			
		}
		
		
		public void viewTasksForProject(String projectName) {
			ArrayList<Task> tasks = taskMap.get(projectName);
			if (tasks == null) {
				System.out.println("No tasks for project: " + projectName);
				return;
			}
			for (Task t : tasks) {
				System.out.println(t);
			}
			
		}
		
		// Checking the key if it is available or not
		public boolean keyInUse(String project) {
			return taskMap.containsKey(project);
		}
		
		/* Deleting a To-Do-List project
		 * 
		 */
		public void deleteProject(String key) {
			if (key== null)
				throw new IllegalArgumentException( " This Key is not vald !");
			
			if (keyInUse(key)) {
				System.out.println("You Are Deleting " + key + " Project ");
				taskMap.remove(key);
			}
			return;
			}
		
		/* Deleting a Task To-Do-List 
		 * 
		 */
		public void deleteTask(int taskindex) {
			int index = (taskindex);
			for (Map.Entry<String, ArrayList<Task>> entry : taskMap.entrySet()) {
				
				System.out.println(" values "+entry.getValue());
			    entry.getValue().remove(index);
			    System.out.println(" values "+entry.getValue().remove(index));
			}
			
			/*String key = projectName(projectname);
			ArrayList<Task> onetask = taskMap.get(key);
			
	 			Iterator<Task> it = onetask.iterator();
	 			while (it.hasNext()) {
	 				Task deletetask =it.next();
	 				if(onetask.contains(index))
	 				it.remove();
	 				tasks.add(task);
	 				taskMap.put(projectname, tasks);
	 			} */
		}
		
		
		// Sorting the Task objects
		static final Comparator <Task> sortByDate = new Comparator <Task>() {
			@Override
			public int compare (Task t1, Task t2) {
				return t1.getTaskDate().compareTo(t2.getTaskDate());
			}
		};
		
		
		
		public void writeToFile() {
			Writefile writeFile = new Writefile();
			writeFile.writeToFile(taskMap);
		}
		
		public void readProjectName() {
			Readfile readprojectname = new Readfile();
			readprojectname.ReadProjectNames();
		}
		
			
}





