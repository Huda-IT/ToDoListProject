package main;

public class Options {

	public Options() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public void printProjectOptions() {
		System.out.println("To Do List Project Options: ");
		System.out.println("------------------------------------------------------------------------------ ");
		System.out.println(" Add new Project, press 1     -------------    Sort All Projects, press 4");
		System.out.println(" View Projects, press 2       ------------     Delete a Project, press 5");
		System.out.println(" Save to a File, press 3      -------------    Exit form the projects, press 6");
		System.out.println('\n');
		
	}
	
	public void printTaskOptions() {
		System.out.println("Task Options: ");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println(" Add new Tasks, press 1      -------------      Edit Tasks, press 4");
		System.out.println(" View Task(s), press 2       -------------      Delete a Task, press 5");
		System.out.println( "Sort Tasks, press 3         -------------      Exit this project, press 6");
		System.out.println('\n');

	}
	
}