package main;
import listManager.TaskManager;
import listManager.Task;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Scanner;

public class Main {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String projectname;
		String description ;
		Date date;
		boolean status;
	    
		
		//HashMap<String, ArrayList<Task> > taskMap ;
		
		Scanner read = new Scanner (System.in);
		TaskManager manager = new TaskManager();
		Options option = new Options();
		
		
		
		boolean process = true;			
		while( process ) {
			
		option.printProjectOptions();
		int choice =read.nextInt();
		if ( choice == 1 ) {
			System.out.println(" Enter Project Name: ");
			projectname = read.next();
			System.out.println('\n');
			
			
			{   
				boolean tProcess = true;			
				while( tProcess ) {
				
				option.printTaskOptions();
				int taskChoice =read.nextInt();
				if ( taskChoice == 1 ) {
					System.out.println(" Add New Tasks: ");
					
					// Scanning Task Description
					System.out.println(" Add Description: ");
					description = read.next();
					
					// Scanning Task Date
					System.out.println(" Add Date in this format: (dd-MM-yyyy)");
					String date1= read.next();	
					SimpleDateFormat dateFormat = new SimpleDateFormat ("dd-MM-yyyy" );
							
					date= null;
					try {
						date = dateFormat.parse(date1);
						System.out.println(dateFormat.format(date));
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						System.out.println(" Error Formatting !");
						e.printStackTrace();
					}
					
					
					// Scanning Task Status
					status = false;
					System.out.println(" Select Status: ");
					status= read.nextBoolean();
					
					if (status== true)
						System.out.println(" Your Task is done! Good job!");
					else 
						System.out.println(" Task is not done yet!! ");
				
					
					Task task = new Task(projectname,  description, date,  status);
					ArrayList<Task> tasks = new ArrayList<Task>(); 
					tasks.add(task);
					manager.AddToHashMap(projectname, tasks);
				}
				
				if ( taskChoice == 2 ) {
					System.out.println(" The Task(s) are: ");
					manager.viewAllTasks();
				}
				
				if ( taskChoice == 3 ) {
					System.out.println(" The Tasks has been saved into a file! ");
				}
				
				if ( taskChoice == 4 ) {
					System.out.println(" Sorted Tasks: ");
				}
				
				if ( taskChoice == 5 ) {
					System.out.println(" Select the Task you want to delete: ");
					int index = read.nextInt();
					manager.deleteTask(index);
				}
				
				if ( taskChoice == 6 ) {
					System.out.println(" You are Done with your Tasks and Existing! ");
					tProcess = false;
				}
				}
			}
			
			/*else if (tasks== null)
			{
				manager.AddToHashMap(projectname, null); */
		}
		
		else if ( choice == 2 ) {
			System.out.println(" The Projects are: ");
			manager.ViewAllProjects();
			
		}
		
		else if ( choice == 3 ) {
			System.out.println(" Your File is Saved! ");
			
	}
		
		else if ( choice == 4 ) {
			System.out.println(" Sorting Projects by Date: ");
			

		}
		
		else if ( choice == 5 ) {
			System.out.println(" Enter Project Name you want delete: ");
			String projectDelete = read.next();
			manager.deleteProject(projectDelete);

		}

		else if ( choice == 6 ) {
			System.out.println(" Done with this project ");
			process = false;
		}
		
		else
			System.out.println(" This is invald option number!! ");
}
	}
}