package listManager;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;





public class TaskManager {
	//Task task = null;
	
	HashMap<String, ArrayList<Task> > taskMap ; 
	ArrayList<Task> tasks = new  ArrayList<Task>();
	String projectname;
	String description;
	Date date;
	boolean status;
	
	
	Task task = new Task (projectname,  description,  date, status) ;
	
	
	public TaskManager() {
		// TODO Auto-generated constructor stub
		taskMap = new HashMap<String, ArrayList<Task>>();
		
	}
	
	
	public String projectName( String projectname) {
		String project = task.getProject();
		return project;
	}
	
	
	
	public ArrayList<Task> addProjectTasks () {
		
		//task= new Task (project,  description,  date, status) ;
		ArrayList<Task> tasks = taskMap.get(projectname);
		if (tasks == null) {
			tasks = new ArrayList<Task>();
			tasks.add(new Task(projectname,  description, date, status));
			taskMap.put(projectname, tasks);
		} else {
			Task newTask = new Task(projectname,  description, date, status);
			if (!tasks.contains(newTask)) {
				tasks.add(new Task(projectname, description, date, status));
				taskMap.put(projectname, tasks);
			}
		}
		return tasks;
	}
	
	public void KeySetArray() {
		Set<String> keySet = taskMap.keySet();
		ArrayList <String> listofkeys = new ArrayList <>(keySet);
	}
	
	public void AddToHashMap(String projectname, ArrayList<Task> tasks ){
		taskMap.put(projectname,tasks);
	}

	
	// View all Projects 
	public void ViewAllProjects() {
		if (tasks == null)
			System.out.println();
		else {
		for (String key: taskMap.keySet())
		System.out.println(key + '\n');
		}
	}
	
	// View all the Tasks in selected project
		public void viewAllTasks() {
			
			for (Map.Entry<String, ArrayList<Task>> key :taskMap.entrySet()) {
				System.out.println(key.getKey() + " : ");
				ArrayList<Task> tasks= key.getValue( );
					for(int i = 0; i < tasks.size(); i++) {
						System.out.printf(i+1 + ": "+  tasks.get(i));
					}
			}
		}
		
		// Checking the key if it is available or not
		public boolean keyInUse(String project) {
			return taskMap.containsKey(project);
		}
		
		/* Deleting a To-Do-List project
		 * 
		 */
		public void deleteProject(String key) {
			if (key== null)
				throw new IllegalArgumentException( " This Key is not vald !");
			
			if (keyInUse(key)) {
				System.out.println("You Are Deleting " + key + " Project ");
				taskMap.remove(key);
			}
			return;
			}
		
		/* Deleting a Task To-Do-List 
		 * 
		 */
		public void deleteTask(int taskindex) {
			int index = (taskindex-1);
			for (Map.Entry<String, ArrayList<Task>> entry : taskMap.entrySet()) {
				
				System.out.println(" values "+entry.getValue());
			    entry.getValue().remove(index);
			    System.out.println(" values "+entry.getValue().remove(index));
			}
			
			/*String key = projectName(projectname);
			ArrayList<Task> onetask = taskMap.get(key);
			
	 			Iterator<Task> it = onetask.iterator();
	 			while (it.hasNext()) {
	 				Task deletetask =it.next();
	 				if(onetask.contains(index))
	 				it.remove();
	 				tasks.add(task);
	 				taskMap.put(projectname, tasks);
	 			} */
				
		}
		
		
			
}





