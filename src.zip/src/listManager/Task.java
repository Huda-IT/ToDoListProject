package listManager;

import java.util.Date;


	public class Task {
		/**
		 * @param project
		 * @param description
		 * @param date
		 * @param status
		 */
		public Task(String project, String description, Date date, boolean status) {
			super();
			this.project = project;
			this.description = description;
			this.date = date;
			this.status = status;
		}

		String project;
		String description; 
		Date date;
		boolean status;
		
		
		/*public Task (String project, String description, Date date, boolean status)  {
			this.project = project;
			this.description= description;
			this.date= date;
			this.status=status;
			
		}  */

		// Set Title method
		public void setProject(String project) {
			this.project = project;
		}
		
		// get Description method
		public String getProject() {
			return project;
		}
		
		// Set Description method
		public void setDescription(String description) {
				this.description= description;
		}
		
		// get Description method
		public String getDescription() {
			return description;
		}
		
		
		// Set Task Date method
		public void setTaskDate(Date date) {
			this.date=date;
		}
		
		
		// get the Date of the Task method
			public Date getTaskDate() {
				return date;
			}
		
		
		// set the condition of the Task
		public void setTaskStatus(boolean status) {
			this.status= status;
		}
		
		
		// get the condition of the Task
		public boolean getTaskStatus() {
			return status;
		}
		
		@Override
		public String toString(){ 
			return   getDescription()+ "   At " + getTaskDate() + "    " + getTaskStatus() + "\n" +"\n";
			
		}
			
		
	}

